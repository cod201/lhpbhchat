'use strict'
const conf = require('../conf');
const static_content = require('../static/static_content');
const messaging = require('../bot/messaging');

let mod = module.exports = {};

mod.INTRO = function(id) {
  messaging.sendQuickReply(id, "Nhắn tin ẩn danh với LHP-ers. Nhấn nút bên dưới để bắt đầu nhé", static_content.QUICK_REPLIES.START_CONVERSATION_PROMPT);
};

mod.NOT_PAIRED = function(id) {
  messaging.sendButtons(id, "", static_content.BUTTONS.REROLL_RETRY);
};

mod.NOT_REGISTERED = function(id) {
  messaging.sendQuickReply(id, "Nhấn bắt đầu trò chuyện đi nè ", static_content.QUICK_REPLIES.START_CONVERSATION_PROMPT);
};

mod.REGISTRATION_ERROR = function(id) {
  messaging.sendText(id, "Không thể bắt đầu cuộc trò chuyện. Vui lòng liên hệ admin (mã 0x1)");
};

mod.USER_ENDED = function(id) {
  messaging.sendButtons(id, " Đã ngưng chat rồi. Bạn muốn tìm người khác không?", static_content.BUTTONS.USER_ENDED_PROMPT);
};

mod.PARTNER_ENDED = function(id) {
  messaging.sendButtons(id, "Người kia đã thoát rồi. Tìm người mới nhé?", static_content.BUTTONS.USER_ENDED_PROMPT);
};

mod.NO_PARTNERS = function(id) {
  messaging.sendText(id, "T_T Không tìm được bất kì ai rảnh hết. Nếu ai đó rảnh thì bạn sẽ được kết nối ngay lập tức");
};

mod.PARTNER_FOUND = function(id) {
    messaging.sendText(id, "😃 Bạn được kết nối với người khác nè! Thả thính đi nào ~~"");
};

mod.PARTNER_FOUND_OTHER = function(id) {
    messaging.sendText(id, "😃 Ai đó đã kết nối với bạn nè!  Thả thính đi nào ~~");
};

mod.USER_TIMEOUT = function(id) {
  messaging.sendQuickReply(id, "⏰ :< Hai bạn không nhắn tin trong mội thời gian nên đã bị ngắt. Tìm người khác nhé", static_content.QUICK_REPLIES.START_CONVERSATION_PROMPT);
};
