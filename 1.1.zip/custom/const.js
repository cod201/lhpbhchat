module.exports = {
	DEBUG : false,

	//FACEBOOK TOKEN
	FB_APP_SECRET : '77adfd6c33b94de68265d88305ae343c',
	FB_PAGE_VERIFY_TOKEN : 'nts0937227240', // đặt 1 mã bất kỳ
	FB_PAGE_ACCESS_TOKEN : 'EAANFAiEgluIBAGNNn8xm2Ws1zZCUoiZCTE2FTiuDMCWfEGLgGrR88ZBaYIkSp7neqsRnuQHSoON172ZAZCtoriuvgrZAcGNjqhMlGGT7Kj52qdVOylxA5KWXJrrDkKc65a9i0R9ZBEOrdbbehy6nkG9eHiZBbZB9yMmktwpHrhWZCdpo155hy3JlCF',

	//HEROKU STUFFS
	APP_NAME : 'null',
	HEROKU_API_KEY : 'null',
	KEEP_APP_ALWAYS_ON : false, // đổi thành true nếu đã thêm credit card vào heroku

	//MONGODB SETUP
	DB_CONFIG_URI : 'mongodb://localhost:27017/anonbot',

	//ANALYTICS
	HAS_POST_LOG : false,
	POST_LOG_ID : '',
	POST_LOG_ENTRY1 : '',
	POST_LOG_ENTRY2 : '',

	//GOOGLE FORMS
	REPORT_LINK : "https://forms.gle/G96Nu8yqdmZu6Kec9",

	//OTHERS
	//(không bắt buộc) Cách bật tính năng hiện đã xem (seen): https://goo.gl/xjw9nP
	MAX_PEOPLE_WAITROOM : 2, //Số người tối đa trong phòng chờ
	MAX_WAIT_TIME_MINUTES : 0, //Số phút tối đa 1 người đc phép trong phòng chờ.
	                            //Đặt 0 để cho phép đợi bao lâu cũng đc

	//ADMIN UI
	ADMIN_PASSWORD : "adminlhp" //password để login vào trang admin
};
